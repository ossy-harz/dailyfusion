  class Recipe {
  final String id;
  final String title;
  final String description;
  final String imageUrl;
  final List<String> ingredients;
  final List<String> steps;
  final int prepTime;
  final int cookTime;
  final int servings;

  Recipe({
  required this.id,
  required this.title,
  required this.description,
  required this.imageUrl,
  required this.ingredients,
  required this.steps,
  required this.prepTime,
  required this.cookTime,
  required this.servings,
  });

  // Create a copy of the recipe with updated fields
  Recipe copyWith({
  String? id,
  String? title,
  String? description,
  String? imageUrl,
  List<String>? ingredients,
  List<String>? steps,
  int? prepTime,
  int? cookTime,
  int? servings,
  }) {
  return Recipe(
  id: id ?? this.id,
  title: title ?? this.title,
  description: description ?? this.description,
  imageUrl: imageUrl ?? this.imageUrl,
  ingredients: ingredients ?? this.ingredients,
  steps: steps ?? this.steps,
  prepTime: prepTime ?? this.prepTime,
  cookTime: cookTime ?? this.cookTime,
  servings: servings ?? this.servings,
  );
  }

  // Convert Recipe to JSON for Firestore
  Map<String, dynamic> toJson() {
  return {
  'title': title,
  'description': description,
  'imageUrl': imageUrl,
  'ingredients': ingredients,
  'steps': steps,
  'prepTime': prepTime,
  'cookTime': cookTime,
  'servings': servings,
  };
  }

  // Create Recipe from Firestore JSON
  factory Recipe.fromJson(Map<String, dynamic> json) {
  return Recipe(
  id: json['id'] ?? '',
  title: json['title'] ?? '',
  description: json['description'] ?? '',
  imageUrl: json['imageUrl'] ?? '',
  ingredients: List<String>.from(json['ingredients'] ?? []),
  steps: List<String>.from(json['steps'] ?? []),
  prepTime: json['prepTime'] ?? 0,
  cookTime: json['cookTime'] ?? 0,
  servings: json['servings'] ?? 0,
  );
  }
  }
