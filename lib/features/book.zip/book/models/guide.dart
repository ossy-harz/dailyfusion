// book/models/guide.dart
class Guide {
  final String id;
  final String title;
  final String content;
  final String imageUrl;
  final String category;

  Guide({
    required this.id,
    required this.title,
    required this.content,
    required this.imageUrl,
    required this.category,
  });

  // Create a copy of the guide with updated fields
  Guide copyWith({
    String? id,
    String? title,
    String? content,
    String? imageUrl,
    String? category,
  }) {
    return Guide(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      imageUrl: imageUrl ?? this.imageUrl,
      category: category ?? this.category,
    );
  }

  // Convert Guide to JSON for Firestore
  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'content': content,
      'imageUrl': imageUrl,
      'category': category,
    };
  }

  // Create Guide from Firestore JSON
  factory Guide.fromJson(Map<String, dynamic> json) {
    return Guide(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      imageUrl: json['imageUrl'] ?? '',
      category: json['category'] ?? 'General',
    );
  }
}