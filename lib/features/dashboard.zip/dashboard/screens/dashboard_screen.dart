import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../widgets/daily_timeline.dart';
import '../widgets/date_selector.dart';
import '../widgets/greeting_header.dart';
import '../widgets/module_summary_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              floating: true,
              pinned: false,
              snap: true,
              title: const Text('Dashboard'),
              actions: [
                IconButton(
                  icon: const Icon(Icons.settings_outlined),
                  onPressed: () {
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                const SizedBox(width: 8),
              ],
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const GreetingHeader(),
                    const SizedBox(height: 16),
                    const DateSelector(),
                    const SizedBox(height: 24),
                    Text(
                      'Daily Planner',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    const DailyTimeline(),
                    const SizedBox(height: 24),
                    Text(
                      'Module Summaries',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    const ModuleSummaryCard(
                      title: 'Fitness',
                      icon: Icons.fitness_center,
                      color: AppColors.fitness,
                      summary: 'Today\'s workout: HIIT - 30 min',
                      progress: 0.6,
                    ),
                    const SizedBox(height: 12),
                    const ModuleSummaryCard(
                      title: 'Budget',
                      icon: Icons.account_balance_wallet,
                      color: AppColors.budget,
                      summary: 'Monthly budget: 65% remaining',
                      progress: 0.65,
                    ),
                    const SizedBox(height: 12),
                    const ModuleSummaryCard(
                      title: 'Tasks',
                      icon: Icons.check_circle,
                      color: AppColors.tasks,
                      summary: '3 tasks due today',
                      progress: 0.4,
                    ),
                    const SizedBox(height: 12),
                    const ModuleSummaryCard(
                      title: 'Book',
                      icon: Icons.book,
                      color: AppColors.book,
                      summary: 'Recipe of the day: Avocado Toast',
                      progress: 0.8,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

